<div class="navbar-area nav-bg-1">
<div class="mobile-responsive-nav">
<div class="container">
<div class="mobile-responsive-menu">
<div class="logo">
<a href="./">
<img src="../assets/images/logo.png" class="main-logo" lt="logo">
<img src="../assets/images/white-logo.png" class="white-logo" alt="logo">
</a>
</div>
</div>
</div>
</div>
<div class="desktop-nav">
<div class="container">
<nav class="navbar navbar-expand-md navbar-light">
<a class="navbar-brand" href="./">
<img src="../assets/images/white-logo.png" alt="logo">
</a>
<div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
<ul class="navbar-nav ms-auto">
<li class="nav-item">
<a href="./" class="nav-link">HOME</a>
</li>
<li class="nav-item">
<a href="#" class="nav-link dropdown-toggle">
ABOUT US
</a>
<ul class="dropdown-menu">
<!-- <li class="nav-item">
<a href="about-us" class="nav-link">Who we are</a>
</li> -->
<li class="nav-item">
<a href="mission-vission" class="nav-link">Mission & Vision</a>
</li>
<li class="nav-item">
<a href="chairman-msg" class="nav-link">Chairman Message</a>
</li>
<li class="nav-item">
<a href="managementboard" class="nav-link">Management Board</a>
</li>
<li class="nav-item">
<a href="ourstaff" class="nav-link">Staff</a>
</li>
</ul>
</li>
<li class="nav-item">
<a href="#" class="nav-link dropdown-toggle">
ACADEMICS
</a>
<ul class="dropdown-menu">
<li class="nav-item">
<a href="admission" class="nav-link">How to Apply</a>
</li>
<li class="nav-item">
<a href="faq" class="nav-link">Our School Fee</a>
</li>
<li class="nav-item">
<a href="javascript:void(0);" class="nav-link">School Anthem</a>
</li>
 <li class="nav-item">
<a href="javascript:void(0);" class="nav-link">Co-curicular Activities</a>
</li> 
 <li class="nav-item">
<a href="javascript:void(0);" class="nav-link">Prospectus</a>
</li> 

</ul>
</li>
<li class="nav-item">
<a href="#" class="nav-link dropdown-toggle">
STUDENTS
</a>
<ul class="dropdown-menu">
<!-- <li class="nav-item">
<a href="health-care" class="nav-link">Student Life</a>
</li> -->
<li class="nav-item">
<a href="ourprefects" class="nav-link">The School Prefects</a>
</li>
<li class="nav-item">
<a href="alumni" class="nav-link">Our Alumni</a>
</li>
<li class="nav-item">
<a href="admission" class="nav-link">Student Admission</a>
</li>
<li class="nav-item">
<a href="onlineresult" class="nav-link">Check Result</a>
</li>
 </ul>
</li>
<li class="nav-item">
<a href="#" class="nav-link dropdown-toggle">
NEWS
</a>
<ul class="dropdown-menu">
<li class="nav-item">
<a href="events" class="nav-link">Events</a>
</li>
<li class="nav-item">
<a href="blog" class="nav-link">Blogs</a>
</li>
</ul>
</li>
<li class="nav-item">
<a href="contact-us" class="nav-link">CONTACT US</a>
</li>
</ul>
<div class="others-options">
<div class="icon">
<i class="ri-menu-3-fill" data-bs-toggle="modal" data-bs-target="#sidebarModal"></i>
</div>
</div>
</div>
</nav>
</div>
</div>
<div class="others-option-for-responsive">
<div class="container">
<div class="dot-menu">
<div class="inner">
<div class="icon">
<i class="ri-menu-3-fill" data-bs-toggle="modal" data-bs-target="#sidebarModal"></i>
</div>
</div>
</div>
</div>
</div>
</div>