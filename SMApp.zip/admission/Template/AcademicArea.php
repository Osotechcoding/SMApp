<div class="academic-area pt-100 pb-70">
<div class="container">
<div class="section-title">
<h2>Welcome to Juli.T.</h2>
<!-- <p>at Juli.T. Schools God is Our Strength</p> -->
</div>
<div class="row justify-content-center">
<div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="200" data-aos-once="true">
<div class="single-academics-card">
<div class="academic-top-content">
<i class="flaticon-college-graduation"></i>
<a href="javascript:void(0);"><h3>Government Approved</h3></a>
</div>
<p>Approved by Ministry of Education.
</div>
</div>
<div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="400" data-aos-once="true">
<div class="single-academics-card">
<div class="academic-top-content">
<i class="flaticon-graduation"></i>
<a href="academics-details"><h3>Conducive Environment</h3></a>
</div>
<p> We leave no stone untruned towards the realization of our goals for your child(ren).</p>
</div>
</div>
<div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="600" data-aos-once="true">
<div class="single-academics-card">
<div class="academic-top-content">
<i class="flaticon-writing-tool"></i>
<a href="academics-details"><h3>Seasoned Teachers</h3></a>
</div>
<p>Our teachers are not only qualified academically but also of high moral values</p>
</div>
</div>
</div>
</div>
</div>