<div class="top-header-area" style="background: darkgrey;">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6 col-md-6">
<div class="header-left-content">
<p>You are Welcome to SMApp Portal</p>
</div>
</div>
<div class="col-lg-6 col-md-6">
<div class="header-right-content">
<div class="list">
<ul>
<li><a href="admission">Admission</a></li>
<li><a href="campus-life">Application</a></li>
<li><a href="eportal/">Portal</a></li>
<li><a href="onlineresult">Result</a></li>
<!-- <li><a href="alumni">Alumni</a></li> -->
</ul>
</div>
</div>
</div>
</div>
</div>
</div>