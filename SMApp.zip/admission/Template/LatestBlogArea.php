<div class="podcasts-area pt-100 pb-70">
<div class="container">
<div class="row">
<div class="col-lg-8">
<div class="section-title style2">
<h2>Our Latest News</h2>
<p>Read from our latest Blog posts</p>
</div>
<div class="single-podcasts-card" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="200" data-aos-once="true">
<div class="row align-items-center">
<div class="col-lg-5 col-md-5">
<div class="podcasts-image">
<img src="assets/images/podcasts/podcasts-1.jpg" alt="Image">
</div>
</div>
<div class="col-lg-7 col-md-7">
<div class="podcast-content">
<span>Category &raquo; &raquo; &nbsp;</span><span>Education</span>
<h3>How To Build Websites That Resonate</h3>
<p>Lorem ipsum dolor sit amet consectetur adipiscing elit ut elit tellus luctus nec ullamcorper mattis</p>
<a href="javascript:void(0);"><span>Read full Content</span></a>

</div>
</div>
</div>
</div>

<div class="single-podcasts-card" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="200" data-aos-once="true">
<div class="row align-items-center">
<div class="col-lg-5 col-md-5">
<div class="podcasts-image">
<img src="assets/images/podcasts/podcasts-1.jpg" alt="Image">
</div>
</div>
<div class="col-lg-7 col-md-7">
<div class="podcast-content">
<span>Category &raquo; &raquo; &nbsp;</span><span>Education</span>
<h3>How To Build Websites That Resonate</h3>
<p>Lorem ipsum dolor sit amet consectetur adipiscing elit ut elit tellus luctus nec ullamcorper mattis</p>
<a href="javascript:void(0);"><span>Read full Content</span></a>

</div>
</div>
</div>
</div>

<div class="single-podcasts-card" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="200" data-aos-once="true">
<div class="row align-items-center">
<div class="col-lg-5 col-md-5">
<div class="podcasts-image">
<img src="assets/images/podcasts/podcasts-1.jpg" alt="Image">
</div>
</div>
<div class="col-lg-7 col-md-7">
<div class="podcast-content">
<span>Category &raquo; &raquo; &nbsp;</span><span>Education</span>
<h3>How To Build Websites That Resonate</h3>
<p>Lorem ipsum dolor sit amet consectetur adipiscing elit ut elit tellus luctus nec ullamcorper mattis</p>
<a href="javascript:void(0);"><span>Read full Content</span></a>

</div>
</div>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="categories">
<h3>Categories</h3>
<ul>
<li><a href="#"><i class="flaticon-briefcase"></i>Business</a></li>
<li><a href="#"><i class="flaticon-fashion"></i>Fashion</a></li>
<li><a href="#"><i class="flaticon-writing-tool"></i>writing</a></li>
<li><a href="#"><i class="flaticon-web-development"></i>Development</a></li>
<li><a href="#"><i class="flaticon-audio-speaker"></i>Marketing</a></li>
</ul>
</div>
<div class="subscribe-area">
<div class="top-content">
<i class="flaticon-email"></i>
<h3>Subscribe To Newsletter</h3>
<p>Get updates to news & events</p>
</div>
<form class="newsletter-form" data-toggle="validator">
<input type="email" class="form-control" placeholder="Your Email" name="EMAIL" required autocomplete="off">
<button class="default-btn" type="submit">
Subscribe
</button>
<div id="validator-newsletter" class="form-result"></div>
</form>
</div>
</div>
</div>
</div>
</div>