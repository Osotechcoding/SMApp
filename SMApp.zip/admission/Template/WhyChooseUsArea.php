<div class="students-stories-area bg-f4f6f9 pt-100 pb-70">
<div class="container">
<div class="section-title">
<h2>Check Student Stories</h2>
<p>Lorem ipsum dolor sit amet consectetur adipiscing elit ut elit tellus luctus nec ullamcorper mattis </p>
</div>
<div class="row justify-content-center">
<div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="200" data-aos-once="true">
<div class="single-stories-card">
<div class="stories-content">
<h3>Why I choose Sanu_Freshman Student</h3>
</div>
<iframe src="https://www.youtube.com/embed/dT9uXvsH6EU" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
</div>
<div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="400" data-aos-once="true">
<div class="single-stories-card">
<div class="stories-content">
<h3>Why I choose Sanu University And Teachers</h3>
</div>
<iframe src="https://www.youtube.com/embed/TM9gjl-8X-E" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
</div>
<div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="600" data-aos-once="true">
<div class="single-stories-card">
<div class="stories-content">
<h3>Why I choose Sanu Campus And Environment</h3>
</div>
<iframe src="https://www.youtube.com/embed/yeZpJ6lJC54" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
</div>
</div>
</div>
</div>