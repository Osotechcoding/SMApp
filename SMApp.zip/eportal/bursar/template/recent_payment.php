 <div class="col-xl-12 col-md-12 col-sm-12 col-12 dashboard-order-summary">
     <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center pb-50">
          <h4 class="card-title">Recent Payment</h4>
        </div>
        <div class="card-body p-0 pb-1">
          <div class="table-responsive">
            <table class="table table-borderless table-marketing-campaigns mb-0">
               <thead class="text-center">
              <tr>
                <th>Student</th>
                <th>Desc</th>
                <th>Amount</th>
                <th>Status</th>
                <th>View</th>
              </tr>
            </thead>
            <tbody class="text-center">
              <tr>
                <td>Osotech Sam</td>
                <td>Tuition</td>
                <td>&#8358;200,000.00</td>
                <td><span class="badge badge-info badge-sm">Part</span></td>
                <td><a href="#"><span class="badge badge-success badge-sm">View</span></a></td>
              </tr>
            </tbody>
            </table>
          </div>
        </div>
     </div>
    </div>