<?php 
if (!defined("__OSOTECH__DEV_COMPANY__")) {
	define("__OSOTECH__DEV_COMPANY__", "Osotech");
	define("__OSO_HOST__",'localhost');
	define("__OSO_USER__",'root');
	define("__OSO_PASS__",'osotech');
	define("__OSO_DBNAME__",'smapp_portal');
	/*define("__OSO_USER__",'smapp_admin');
	define("__OSO_PASS__",'@smapp123');
	define("__OSO_DBNAME__",'smapp_portal');*/
	define("__OSO_DB_DRIVER__",'mysql');
	define("__OSO_CHARSET__",'utf8mb4');
	define("__OSO_SERIAL__NUMBER_","XTAS-KM87-EWA6-09CQ-5J0V");
	define("__OSO__CONTROL__KEY__","smapp123");
	define("__OSO_APP_VERSION__","v1.1.1");
	define("__OSO_APP_DEV_YEAR__","2022");
	define("__OSO_APP_NAME__","SMApp");
	define("__SCHOOL_NAME__","School Management Application E-Portal");
	define("__SCHOOL_LOCATION_ADDRESS__","Plot 1, Block 2, SMApp Avenue, Lagos, Nigeria");
	define("APP_ROOT","http://localhost/smapp/eportal/");
	//define("APP_ROOT","https://eportal.smapp.com/");
	
}